# Mini-CRM

A small customer relationship manager (contacts, companies, deals) built with FastAPI, SQLAlchemy, and PostgreSQL. Built as a hands-on learning project in public.

> **Status:** Week 0 (skeleton). See [docs/ROADMAP.md](docs/ROADMAP.md) for the plan.

## Tech stack
- **Backend:** Python 3.12, FastAPI, SQLAlchemy 2, Pydantic 2
- **Database:** SQLite (dev, Weeks 1-3) then PostgreSQL
- **Testing:** pytest
- **CI:** GitHub Actions
- **Front end:** React + Vite (Week 5)
- **Deploy:** Docker, Render/Railway (Week 6)

## Requirements
- Python 3.12 or newer
- Git
- A code editor (VS Code recommended)
- Later: Docker Desktop, Node.js 20+

## Quick start

```bash
cd backend
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt

pytest -q                        # run the tests
uvicorn app.main:app --reload    # start the API
```

Then open http://127.0.0.1:8000/docs for the interactive API docs.

## Project layout

```
mini-crm/
├── backend/
│   ├── app/
│   │   ├── main.py        # routes (move to routers/ in Week 2)
│   │   ├── models.py      # database tables
│   │   ├── schemas.py     # request/response shapes
│   │   └── database.py    # engine and session
│   ├── tests/
│   └── requirements.txt
├── docs/
│   ├── ROADMAP.md         # week-by-week plan
│   └── LEARNING_LOG.md    # your notes
└── .github/workflows/ci.yml
```

## Design decisions
_Fill this in as you build. For each choice, write what you picked, what you rejected, and why._

## Roadmap
- [x] Week 0: skeleton, first endpoints, CI
- [ ] Week 1: Contacts CRUD with tests
- [ ] Week 2: Companies and Deals
- [ ] Week 3: Auth and roles
- [ ] Week 4: Postgres, migrations, Docker
- [ ] Week 5: Front end
- [ ] Week 6: Deploy and polish
