# Mini-CRM: 6-Week Hands-On Roadmap

Rule of thumb: **read the lesson, build the feature yourself, then write a short note in `docs/LEARNING_LOG.md`** about what broke and what you learned. That log becomes interview material.

For each week: commit small and often, open a PR for each feature even though you are solo, and keep tests green.

---

## Week 1: Python, HTTP, and your first API (Contacts CRUD)

**Lessons**
- How HTTP works: methods (GET/POST/PATCH/DELETE), status codes (200, 201, 404, 409, 422)
- Python type hints and Pydantic validation
- FastAPI routing, dependency injection (`Depends`), and the `/docs` page
- pytest basics and test-driven development (TDD)

**Build**
1. Run the app and click through `/docs`. Break things on purpose and read the errors.
2. Write failing tests, then implement:
   - `GET /contacts/{id}` (404 when missing)
   - `PATCH /contacts/{id}` (partial update via `ContactUpdate` schema)
   - `DELETE /contacts/{id}` (204)
3. Add email validation (`EmailStr`) and a search filter: `GET /contacts?q=ada`.

**Checkpoint:** you can explain the path of a request from client to database and back.

---

## Week 2: Relational data modeling

**Lessons**
- Tables, primary/foreign keys, one-to-many vs many-to-many
- SQLAlchemy relationships and `joinedload` (and what the N+1 problem is)
- Organizing code with `APIRouter` (split `main.py` into `routers/`)

**Build**
1. Add `Company` and `Deal` models (Deal: stage, amount, contact_id, company_id).
2. Full CRUD for both, as separate router files.
3. Deal stages as an Enum: `lead -> qualified -> proposal -> won / lost`.
4. Endpoint: `GET /deals/summary` returning total amount per stage (a SQL `GROUP BY`).

**Checkpoint:** draw your ER diagram (add it to the README) and explain every relationship.

---

## Week 3: Authentication and authorization

**Lessons**
- Password hashing (bcrypt/argon2, never plain text) and why
- JWT tokens vs sessions; how a bearer token is checked
- Authentication (who are you) vs authorization (what may you do)

**Build**
1. `User` model with `role` (`admin` / `rep`).
2. `POST /auth/register` and `POST /auth/login` returning a JWT.
3. Protect all CRM routes with a dependency that reads the token.
4. Rule: reps see only their own deals; admins see everything. Add an `owner_id` to Deal.
5. Tests for: no token (401), wrong role (403), happy path.

**Checkpoint:** you can explain how a stolen token is limited and what you would add next (expiry, refresh).

---

## Week 4: PostgreSQL, migrations, and Docker

**Lessons**
- Why migrations exist; Alembic basics
- Environment variables and config (never commit secrets)
- Docker and docker-compose fundamentals

**Build**
1. Replace `create_all` with Alembic migrations.
2. `docker-compose.yml` running the API and Postgres together.
3. Move settings (DB URL, JWT secret) to environment variables with a `.env.example`.
4. Update CI to run tests against a Postgres service container.

**Checkpoint:** a stranger can clone the repo and run `docker compose up` successfully.

---

## Week 5: Front end

**Lessons**
- `fetch`, async/await, and CORS
- Components and state (React with Vite is a good choice; plain JS is acceptable)

**Build**
1. Login page that stores the token.
2. Contacts table with search, create, edit, delete.
3. Deals board grouped by stage (a simple Kanban column layout is enough).
4. Show loading and error states.

**Checkpoint:** a recruiter can use the app in under two minutes without instructions.

---

## Week 6: Polish and deploy

**Build**
1. Deploy to Render or Railway; add the live link to the README.
2. README: screenshot or demo GIF, architecture diagram, setup steps, and a "Design decisions" section.
3. Add pagination, input validation errors, and logging.
4. Tag a `v1.0` release.

**Checkpoint:** you can walk through the whole system in a 5-minute demo.

---

## Interview questions this project prepares you for
- Walk me through what happens when a user logs in.
- Why separate models from schemas?
- What is the N+1 problem and how did you avoid it?
- How would you scale this if it had 1M contacts?
- What would you test first, and why?

## Stretch goals (after v1.0)
- Activity timeline per contact
- CSV import/export
- Rate limiting
- Plug in the lead-scoring ML service (Project 2)
