# Learning Log

One entry per work session. Keep it honest; bugs and dead ends are the interesting part.

## Template

**Date:**
**What I built:**
**What broke and how I fixed it:**
**What I learned:**
**Question to answer next time:**

---

## Week 1 entries

