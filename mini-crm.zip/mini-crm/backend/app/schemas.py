"""Pydantic schemas: what the API accepts and returns.

Models (models.py) describe the database. Schemas describe the JSON contract.
Keeping them separate is a core design habit worth being able to explain in
interviews.
"""
from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict


class ContactBase(BaseModel):
    first_name: str
    last_name: str
    email: str
    phone: Optional[str] = None


class ContactCreate(ContactBase):
    pass


class ContactOut(ContactBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    created_at: datetime


# TODO (Week 1): ContactUpdate (all fields optional) for PATCH
# TODO (Week 2): Company and Deal schemas
