"""SQLAlchemy models (your database tables).

Worked example: Contact is done for you. Study it, then build Company and Deal
yourself in Week 2 following the same pattern.
"""
from datetime import datetime, timezone

from sqlalchemy import Column, DateTime, Integer, String

from .database import Base


class Contact(Base):
    __tablename__ = "contacts"

    id = Column(Integer, primary_key=True, index=True)
    first_name = Column(String, nullable=False)
    last_name = Column(String, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    phone = Column(String, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))


# TODO (Week 2): class Company(Base): ...
# TODO (Week 2): class Deal(Base): ...  (stage, amount, contact_id, company_id)
# TODO (Week 3): class User(Base): ...  (email, hashed_password, role)
