"""App entry point. Run with:  uvicorn app.main:app --reload  (from backend/)

Interactive API docs are auto-generated at http://127.0.0.1:8000/docs
"""
from fastapi import Depends, FastAPI, HTTPException
from sqlalchemy.orm import Session

from . import models, schemas
from .database import Base, engine, get_db

Base.metadata.create_all(bind=engine)  # Week 4: replace with Alembic migrations

app = FastAPI(title="Mini-CRM", version="0.1.0")


@app.get("/health")
def health():
    return {"status": "ok"}


# --- Contacts: worked example (create + list). You build the rest. ---------


@app.post("/contacts", response_model=schemas.ContactOut, status_code=201)
def create_contact(payload: schemas.ContactCreate, db: Session = Depends(get_db)):
    if db.query(models.Contact).filter_by(email=payload.email).first():
        raise HTTPException(status_code=409, detail="Email already exists")
    contact = models.Contact(**payload.model_dump())
    db.add(contact)
    db.commit()
    db.refresh(contact)
    return contact


@app.get("/contacts", response_model=list[schemas.ContactOut])
def list_contacts(db: Session = Depends(get_db)):
    return db.query(models.Contact).order_by(models.Contact.id).all()


# TODO (Week 1): GET /contacts/{id}  -> 404 if missing
# TODO (Week 1): PATCH /contacts/{id}
# TODO (Week 1): DELETE /contacts/{id}
# TODO (Week 2): move routes into app/routers/ using APIRouter
